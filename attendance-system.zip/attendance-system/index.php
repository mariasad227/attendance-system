<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Attendance System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: linear-gradient(135deg, #667eea, #764ba2); margin:0; height:100vh; display:flex; align-items:center; justify-content:center; }
        .login-box { background:white; padding:40px; border-radius:16px; box-shadow:0 20px 40px rgba(0,0,0,0.3); width:100%; max-width:420px; }
        h2 { text-align:center; margin-bottom:10px; }
        p { text-align:center; color:#666; margin-bottom:30px; }
        input { width:100%; padding:14px; margin:10px 0; border:1px solid #ddd; border-radius:8px; font-size:16px; }
        button { width:100%; padding:14px; background:#3498db; color:white; border:none; border-radius:8px; font-size:18px; cursor:pointer; }
        button:hover { background:#2980b9; }
        .error { color:#e74c3c; text-align:center; margin-top:15px; }
    </style>
</head>
<body>
<div class="login-box">
    <h2>Attendance System</h2>
    <p>Algiers University</p>

    <?php
    require 'config/db.php';

    if ($_POST) {
        $email = trim($_POST['email']);
        $password = $_POST['password'];

        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['first_name'] . ' ' . $user['last_name'];
            header("Location: dashboard.php");
            exit();
        } else {
            echo "<p class='error'>Invalid email or password</p>";
        }
    }
    ?>

    <form method="POST">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>

    <br>
    <small style="text-align:center;display:block;color:#777;">
        <strong>Demo Accounts:</strong><br>
        Admin: admin@univ.dz / admin123<br>
        Professor: prof@univ.dz / prof123<br>
        Student: sara@univ.dz / student123
    </small>
</div>
</body>
</html>