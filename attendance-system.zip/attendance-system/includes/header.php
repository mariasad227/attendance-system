<header>
    <nav class="navbar">
        <div class="container">
            <h1>Attendance System</h1>
            <ul>
                <li>Welcome, <strong><?= $_SESSION['name'] ?></strong></li>
                <li><a href="logout.php" style="color:#e74c3c;">Logout</a></li>
            </ul>
        </div>
    </nav>
</header>