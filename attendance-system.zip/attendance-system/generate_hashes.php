<?php
$passwords = ['admin123', 'prof123', 'student123'];
foreach ($passwords as $pass) {
    echo $pass . ": " . password_hash($pass, PASSWORD_DEFAULT) . "\n";
}
?>