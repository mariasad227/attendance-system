<?php
require 'config/db.php';
if (!isset($_SESSION['user_id'])) header("Location: index.php");
$user_id = $_SESSION['user_id'];
$role    = $_SESSION['role'];
$name    = $_SESSION['name'];

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= ucfirst($role) ?> Dashboard • Attendance System</title>
    
    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --gray: #6b7280;
            --bg: #f8fafc;
            --card: rgba(255, 255, 255, 0.85);
            --text: #1e293b;
            --border: rgba(255, 255, 255, 0.2);
        }
        .dark-mode {
            --bg: #0f172a;
            --card: rgba(15, 23, 42, 0.8);
            --text: #e2e8f0;
            --border: rgba(255, 255, 255, 0.1);
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: var(--text);
            min-height: 100vh;
            background-attachment: fixed;
        }
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }

        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0; top: 0; bottom: 0;
            width: 280px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--border);
            padding: 2rem 1.5rem;
            z-index: 1000;
            transition: all 0.4s;
        }
        .sidebar-header {
            text-align: center;
            margin-bottom: 3rem;
        }
        .logo {
            font-size: 2rem;
            font-weight: 800;
            color: white;
            text-shadow: 0 4px 10px rgba(0,0,0,0.3);
        }
        .user-info {
            background: rgba(255,255,255,0.15);
            padding: 1.5rem;
            border-radius: 16px;
            text-align: center;
            margin-bottom: 2rem;
            backdrop-filter: blur(10px);
        }
        .avatar {
            width: 80px; height: 80px;
            background: linear-gradient(45deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            margin: 0 auto 1rem;
            display: flex; align-items: center; justify-content: center;
            font-size: 2rem; color: white; font-weight: bold;
        }
        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 1rem 1.5rem;
            color: white;
            text-decoration: none;
            border-radius: 12px;
            margin-bottom: 0.5rem;
            transition: all 0.3s;
            font-weight: 500;
        }
        .nav-menu a:hover, .nav-menu a.active {
            background: rgba(255,255,255,0.2);
            transform: translateX(10px);
        }
        .nav-menu i { margin-right: 12px; width: 20px; }

        /* Main Content */
        .main-content {
            margin-left: 280px;
            padding: 2rem;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        .page-title { font-size: 2.5rem; font-weight: 800; color: white; text-shadow: 0 4px 20px rgba(0,0,0,0.3); }
        
        /* Cards Grid */
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .card {
            background: var(--card);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 1.8rem;
            border: 1px solid var(--border);
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            transition: all 0.4s;
        }
        .card:hover { transform: translateY(-10px); box-shadow: 0 30px 60px rgba(0,0,0,0.2); }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        .card-title {
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--text);
        }
        .stat-value {
            font-size: 3rem;
            font-weight: 800;
            background: linear-gradient(45deg, var(--primary), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .chart-container {
            height: 300px;
            position: relative;
        }

        /* Theme Toggle */
        .theme-toggle {
            background: rgba(255,255,255,0.2);
            width: 60px; height: 30px;
            border-radius: 50px;
            position: relative;
            cursor: pointer;
        }
        .theme-toggle::after {
            content: '';
            position: absolute;
            width: 26px; height: 26px;
            border-radius: 50%;
            background: white;
            top: 2px; left: 2px;
            transition: 0.4s;
        }
        .dark-mode .theme-toggle::after { left: 32px; }

        /* Live Clock */
        .live-clock {
            font-size: 1.1rem;
            color: white;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="logo">Attendance</div>
        </div>
        
        <div class="user-info">
            <div class="avatar"><?= strtoupper(substr($name, 0, 2)) ?></div>
            <h3><?= explode(' ', $name)[0] ?></h3>
            <p style="color:#ccc; font-size:0.9rem; margin-top:0.5rem;">
                <strong><?= ucfirst($role) ?></strong>
            </p>
        </div>

        <div class="nav-menu">
            <a href="dashboard.php" class="active"><i class="fas fa-home"></i> Dashboard</a>
            <?php if($role=='admin'): ?>
                <a href="admin/statistics.php"><i class="fas fa-chart-bar"></i> Statistics</a>
                <a href="admin/manage_students.php"><i class="fas fa-users-cog"></i> Manage Students</a>
            <?php elseif($role=='professor'): ?>
                <a href="professor/sessions.php"><i class="fas fa-calendar-check"></i> My Sessions</a>
                <a href="professor/summary.php"><i class="fas fa-table"></i> Summary</a>
            <?php elseif($role=='student'): ?>
                <a href="student/my_courses.php"><i class="fas fa-book"></i> My Courses</a>
                <a href="student/justify_absence.php"><i class="fas fa-file-medical"></i> Justify Absence</a>
            <?php endif; ?>
            <a href="logout.php" style="margin-top:3rem;color:#ff6b6b;"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="top-bar">
            <div class="page-title">Welcome back, <?= explode(' ', $name)[0] ?>!</div>
            <div style="display:flex; align-items:center; gap:1rem;">
                <div class="live-clock" id="clock"></div>
                <div class="theme-toggle" id="themeToggle"></div>
            </div>
        </div>

        <!-- Stats Grid -->
        <div class="grid">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Total Students</div>
                    <i class="fas fa-users" style="font-size:2rem; color:var(--primary);"></i>
                </div>
                <div class="stat-value" data-count="<?= $pdo->query("SELECT COUNT(*) FROM users WHERE role='student'")->fetchColumn() ?>">0</div>
            </div>

            <div class="card">
                <div class="card-header">
                    <div class="card-title">Active Sessions</div>
                    <i class="fas fa-clock" style="font-size:2rem; color:var(--success);"></i>
                </div>
                <div class="stat-value" data-count="<?= $pdo->query("SELECT COUNT(*) FROM sessions WHERE status='open'")->fetchColumn() ?>">0</div>
            </div>

            <div class="card">
                <div class="card-header">
                    <div class="card-title">Justifications</div>
                    <i class="fas fa-file-alt" style="font-size:2rem; color:var(--warning);"></i>
                </div>
                <div class="stat-value" data-count="<?= $pdo->query("SELECT COUNT(*) FROM justifications")->fetchColumn() ?>">0</div>
            </div>

            <div class="card">
                <div class="card-header">
                    <div class="card-title">Today's Date</div>
                    <i class="fas fa-calendar" style="font-size:2rem; color:var(--primary);"></i>
                </div>
                <div style="font-size:2rem; font-weight:700; color:white;">
                    <?= date('d M Y') ?>
                </div>
            </div>
        </div>

        <!-- Chart -->
        <div class="card" style="grid-column: 1 / -1;">
            <div class="card-header">
                <div class="card-title">Attendance Overview</div>
            </div>
            <div class="chart-container">
                <canvas id="attendanceChart"></canvas>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script>
        // Live Clock
        function updateClock() {
            const now = new Date();
            document.getElementById('clock').textContent = now.toLocaleTimeString('en-GB');
        }
        setInterval(updateClock, 1000);
        updateClock();

        // Animated Counters
        $('.stat-value').each(function() {
            const count = $(this).data('count');
            $(this).prop('Counter', 0).animate({
                Counter: count
            }, {
                duration: 2000,
                easing: 'swing',
                step: function(now) {
                    $(this).text(Math.ceil(now));
                }
            });
        });

        // Theme Toggle
        $('#themeToggle').click(function() {
            $('body').toggleClass('dark-mode');
        });

        // Sample Chart
        new Chart(document.getElementById('attendanceChart'), {
            type: 'doughnut',
            data: {
                labels: ['Present', 'Absent', 'Justified'],
                datasets: [{
                    data: [78, 15, 7],
                    backgroundColor: ['#10b981', '#ef4444', '#f59e0b'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { position: 'bottom', labels: { color: 'white' } } }
            }
        });
    </script>
</body>
</html>