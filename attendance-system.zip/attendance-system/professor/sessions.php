<?php require '../config/db.php'; 
if ($_SESSION['role'] != 'professor') header("Location: ../dashboard.php");
?>
<!DOCTYPE html>
<html><head><title>My Sessions</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body>
<?php include '../includes/header.php'; ?>
<main class="container">
    <div class="card">
        <h2>My Teaching Sessions</h2>
        <p>List of all sessions you can mark attendance for.</p>
        <ul>
            <li><a href="mark_attendance.php?session=1">Advanced Web Programming - 25 Nov 2025</a></li>
            <li><a href="mark_attendance.php?session=2">Database Systems - 27 Nov 2025</a></li>
        </ul>
    </div>
</main>
</body></html>