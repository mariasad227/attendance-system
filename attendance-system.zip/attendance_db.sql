-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 28, 2025 at 09:12 PM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance_records`
--

DROP TABLE IF EXISTS `attendance_records`;
CREATE TABLE IF NOT EXISTS `attendance_records` (
  `id` int NOT NULL AUTO_INCREMENT,
  `session_id` int NOT NULL,
  `student_id` int NOT NULL,
  `is_present` tinyint(1) DEFAULT '0',
  `participation` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_attendance` (`session_id`,`student_id`),
  KEY `student_id` (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance_records`
--

INSERT INTO `attendance_records` (`id`, `session_id`, `student_id`, `is_present`, `participation`, `created_at`) VALUES
(1, 1, 3, 1, 1, '2025-11-28 19:38:07'),
(2, 2, 3, 0, 1, '2025-11-28 19:38:07'),
(3, 3, 3, 1, 1, '2025-11-28 19:38:07'),
(4, 4, 3, 0, 0, '2025-11-28 19:38:07'),
(5, 5, 3, 1, 0, '2025-11-28 19:38:07'),
(6, 6, 3, 1, 0, '2025-11-28 19:38:07'),
(7, 1, 4, 0, 0, '2025-11-28 19:38:07'),
(8, 2, 4, 0, 0, '2025-11-28 19:38:07'),
(9, 3, 4, 1, 1, '2025-11-28 19:38:07'),
(10, 4, 4, 0, 0, '2025-11-28 19:38:07'),
(11, 5, 4, 0, 0, '2025-11-28 19:38:07'),
(12, 6, 4, 1, 1, '2025-11-28 19:38:07'),
(13, 1, 5, 0, 0, '2025-11-28 19:38:07'),
(14, 2, 5, 0, 0, '2025-11-28 19:38:07'),
(15, 3, 5, 0, 0, '2025-11-28 19:38:07'),
(16, 4, 5, 0, 0, '2025-11-28 19:38:07'),
(17, 5, 5, 0, 0, '2025-11-28 19:38:07'),
(18, 6, 5, 1, 0, '2025-11-28 19:38:07');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
CREATE TABLE IF NOT EXISTS `courses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  `professor_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `professor_id` (`professor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `code`, `name`, `professor_id`, `created_at`) VALUES
(1, 'AWP2025', 'Advanced Web Programming', 2, '2025-11-28 19:38:07');

-- --------------------------------------------------------

--
-- Table structure for table `course_groups`
--

DROP TABLE IF EXISTS `course_groups`;
CREATE TABLE IF NOT EXISTS `course_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `course_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course_groups`
--

INSERT INTO `course_groups` (`id`, `name`, `course_id`) VALUES
(1, 'G1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `justifications`
--

DROP TABLE IF EXISTS `justifications`;
CREATE TABLE IF NOT EXISTS `justifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `session_id` int NOT NULL,
  `reason` text COLLATE utf8mb4_general_ci NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_general_ci DEFAULT 'pending',
  `submitted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewed_by` int DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `session_id` (`session_id`),
  KEY `reviewed_by` (`reviewed_by`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `justifications`
--

INSERT INTO `justifications` (`id`, `student_id`, `session_id`, `reason`, `file_path`, `status`, `submitted_at`, `reviewed_by`, `reviewed_at`) VALUES
(1, 3, 2, 'Medical appointment - Doctor certificate attached', 'uploads/justif_sara_nov5.pdf', 'approved', '2025-11-28 19:38:07', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `course_id` int NOT NULL,
  `group_id` int NOT NULL,
  `session_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time DEFAULT NULL,
  `status` enum('open','closed') COLLATE utf8mb4_general_ci DEFAULT 'open',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `course_id`, `group_id`, `session_date`, `start_time`, `end_time`, `status`, `created_at`) VALUES
(1, 1, 1, '2025-11-01', '08:00:00', NULL, 'closed', '2025-11-28 19:38:07'),
(2, 1, 1, '2025-11-05', '08:00:00', NULL, 'closed', '2025-11-28 19:38:07'),
(3, 1, 1, '2025-11-08', '08:00:00', NULL, 'closed', '2025-11-28 19:38:07'),
(4, 1, 1, '2025-11-12', '08:00:00', NULL, 'closed', '2025-11-28 19:38:07'),
(5, 1, 1, '2025-11-15', '08:00:00', NULL, 'closed', '2025-11-28 19:38:07'),
(6, 1, 1, '2025-11-19', '08:00:00', NULL, 'open', '2025-11-28 19:38:07');

-- --------------------------------------------------------

--
-- Table structure for table `student_groups`
--

DROP TABLE IF EXISTS `student_groups`;
CREATE TABLE IF NOT EXISTS `student_groups` (
  `student_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`student_id`,`group_id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_groups`
--

INSERT INTO `student_groups` (`student_id`, `group_id`) VALUES
(3, 1),
(4, 1),
(5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `first_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `role` enum('student','professor','admin') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'student',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `student_id` (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `student_id`, `first_name`, `last_name`, `email`, `password`, `role`, `created_at`) VALUES
(1, '00001', 'System', 'Administrator', 'admin@univ.dz', '$2y$10$tF41C3EU2lFh1XlsijF1DeptMPiV3OlsXsozmP5UzinudCGiWWUoe', 'admin', '2025-11-28 19:38:06'),
(2, '10001', 'Mohamed', 'Boutaba', 'prof@univ.dz', '$2y$10$9UwsWuTLWyX6nlQczyIQi.eeHWJo/mQzFBT2d8iUkDzhLpltqCnD2', 'professor', '2025-11-28 19:38:06'),
(3, '21001', 'Sara', 'Ahmed', 'sara.ahmed@univ.dz', '$2y$10$ZfcMdxHntDVFbH/XwPHlxuKSZU0J0NU.AcMDGQdsd/9sbD.XyuTDS', 'student', '2025-11-28 19:38:06'),
(4, '21002', 'Ali', 'Yacine', 'ali.yacine@univ.dz', '$2y$10$ZfcMdxHntDVFbH/XwPHlxuKSZU0J0NU.AcMDGQdsd/9sbD.XyuTDS', 'student', '2025-11-28 19:38:06'),
(5, '21003', 'Rania', 'Houcine', 'rania.houcine@univ.dz', '$2y$10$ZfcMdxHntDVFbH/XwPHlxuKSZU0J0NU.AcMDGQdsd/9sbD.XyuTDS', 'student', '2025-11-28 19:38:06');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance_records`
--
ALTER TABLE `attendance_records`
  ADD CONSTRAINT `attendance_records_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendance_records_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`professor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `course_groups`
--
ALTER TABLE `course_groups`
  ADD CONSTRAINT `course_groups_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `justifications`
--
ALTER TABLE `justifications`
  ADD CONSTRAINT `justifications_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `justifications_ibfk_2` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `justifications_ibfk_3` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `sessions`
--
ALTER TABLE `sessions`
  ADD CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sessions_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `course_groups` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_groups`
--
ALTER TABLE `student_groups`
  ADD CONSTRAINT `student_groups_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_groups_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `course_groups` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
